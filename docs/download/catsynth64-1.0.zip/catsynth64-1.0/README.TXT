CATSYNTH 64 v1.0                               (c) 2026 illobo/netmilk

A toy synth for the Commodore 64: three cats in a band. The drum cat,
the bass cat and the singer cat play a little song; you change it, play
over it and record into it. Ten styles, from dancehall to blues
shuffle; every riff is original, written in the style of its genre.

LOAD"CATSYNTH64",8,1 and RUN. PAL C64, C64 Ultimate or Ultimate 64.
Mouse in port 1 (a 1351, or the C64 Ultimate's USB mouse) and joystick
in port 2, both optional. A second SID is used for the echoes, the
harmony and the bass delay when present.

THE PANEL
  Tabs Drums | Bass | Meows (one cat at a time), play/pause, stop,
  record, tempo in BPM (- +). Under them the open cat's bar: 16 steps
  by 7 rows. Drums: a row per pair of sounds (BD/BM, SN/BP, CP/RS,
  CH/OH, SH/RD, GH/DU, SK/DR), the left one a block, the right a ball.
  Bass: the notes of the scale. Meows: the scale's degrees; a ball is
  a mew, a heart a meow, a ring an ooh, ? a mrr; grey: the echoes.
  The frame's bottom line: a floppy icon at the right (the disk page).
  Next to last line: the open cat's settings. Bottom: the song slot's
  key and name, mode, bars A-D, - and + (the chain shorter / longer),
  the chain (click a bar to change it: A B C D; right click: back).

SONG SLOTS
  Ten songs in memory, on the keys 1-9, 0; at start the ten styles'
  songs (1 dancehall ... 0 shuffle). Each slot keeps its own edits
  until power off (save to disk to keep them). While the band plays a
  switch waits for the end of the bar ("Next bar: slot N"), stopped it
  is at once; the open slot's key calls a waiting switch off. The new
  song plays from its top. SHIFT+1-0: the open song gets that style's
  sounds (kit, bass, key, scale, harmony; the bass and meows follow
  the new key and scale); the bars, chain, tempo and settings stay.
  Bottom left: the slot's key and name (the style's, or the file's
  first 9 letters once loaded or saved). Click the name: the next
  slot; right-click: the style list over the matrix ("1 Dancehall"
  ... "0 Shuffle", the open song's style white): click a style or
  press 1-0 for its sounds; T or a right click on the name closes it.

MOUSE
  Left / right click on a step: drums: the row's left / right sound
  (again: off); bass: a note (on it: off) / a sliding note (on a note:
  its length); singer: a meow (on it: off) / on a meow: the next kind.
  Clicks also work on the tabs, the buttons, the tempo, the settings
  line and the bottom line. The first click wakes the pointer.
  Mute a cat: right-click its tab (or CTRL+1 / 2 / 3); its name turns
  light red.

SETTINGS PAGES
  Click the open tab (or T) and its cat's settings page covers the
  matrix; again, T, "T back" or another tab closes it; C= goes to the
  next cat's page. Each item: Label <value>; click < or > to step,
  right-click to reset (as made), click the label to select it; a box
  [ ] ticks with a click. Keys: CRSR up/down the item, CRSR left/right
  or Q / A the value, RETURN play the cat, SHIFT+RETURN reset. The
  bottom line: "<Cat> tweaks  RMB reset  [ ] Preview  T back"; tick
  Preview (or press P) and each change plays the cat (off at first;
  RETURN always plays it). 0 = as made.
  Meows: per kind (Mew, Meow, Ooh, Mrr?; click it to hear it and to
    choose it for new meows): Bend -8 (a straight note) .. +8 (four
    times the swoop, still landing on the note), Vowel -8 (closed mmm)
    .. +8 (three times as wide), Tone -8 darker .. +8 brighter. Echoes
    and harmony follow. Under them Cat Size: Fat Cat (as made,
    loudest), Tomcat, Kitten, Newborn (a third as loud); < smaller,
    > bigger, right-click: Fat Cat again.
  Drums: Sidechain 0 (off) .. 8: each kick (BD, BM) ducks the bass,
    quieter and thinner, back over half a beat (its pulse width);
    Tune -8 (half the pitch) .. +8 (one and a half times). No level:
    a drum hit is all attack (turn the others down instead).
    [ ] Beat pulse (off at first): kicks, snares and claps light the
    border in their colour.
  Bass: Level 0 .. -8 (quieter); Delay off, 1 2 3 4 6 8 12 steps
    (the bass again, quieter, on SID 2's third voice: needs a second
    SID, else the page says "Delay: on SID 2"); Wave Style, Pulse,
    Saw, Tri (saw and tri are quieter down low); [ ] Meowize: the
    bass through the meows' filter, so the vowels wah the bass;
    [ ] Res boost: that filter's resonance at the top, and with
    Meowize each bass note sweeps it while no meow sings: an acid
    squelch (the meows ring too); [ ] Dub filter: the bass delay's
    repeats through SID 2's filter, resonance up, bright to dark (a
    ringing dub "wow"; the echo meows ring a little more too).
  A style's song sets them all (neko trap: its own meows and a light
  sidechain); they belong to the song: each slot keeps its own, they
  are saved with it, and SHIFT+1-0 leaves them as they are.

DISK PAGE
  S, L or the floppy icon opens it; the band plays on (the music
  pauses only while the drive works). The directory of drive 8: disk
  name and ID, files (blocks, name, type), blocks free; click the big
  floppy to read it again. Click a file (or CRSR up/down) to put its
  name in the Name field, or type one (letters, digits, space, + - .;
  DEL; 16 characters). Load (RETURN) into the open slot, Save
  (SHIFT+RETURN) the open slot (either way the slot takes the name),
  Delete (F7), Dir (F1), Back (RUN/STOP), New (click). Saving over a
  file and deleting ask first: Yes / No (Y / N). New asks "New:  This
  slot  All slots  Defaults  No" (T / A / D / N): an empty song in the
  slot's style (its tempo, sounds and settings, one bar A), the same
  in all ten slots, or the ten styles' songs back; then the open slot
  starts from the top. Old CATSONG0-9 files load like any other.
  The program disk has ten techno songs to load into the slots: ACID
  ALLEYCAT, BERLIN BASEMENT, DETROIT WHISKERS, DUB TECHNO NAP, HARD
  PURR, LASER POINTER, MINIMAL MOUSER, RAVE OF 9 LIVES, TECHNO TABBY,
  WAREHOUSE KITTY.

KEYS
  1-9, 0      song slot (at the bar's end)  SPACE   play / stop
  SHIFT+1-0   the open song in that style's sounds (kit, bass, key)
  + -         tempo                         CRSR    move the cursor
  RETURN      left job (as a left click)    C=      next cat's tab
  SHIFT+RETURN right job (a right click)    Q A     value up / down
  K           length (bass), meow kind      G       bass slide
  F1 F3 F5 F7 edit bar A B C D              C       song order (AAAB)
  E           echo (dub)                    X       copy bar A here
  DEL         clear the open cat's steps    S / L   the disk page
  , .         singer transpose down / up (in key, saved with the song)
  < >         bass transpose down / up (SHIFT + , .; in key)
  M           mode: the style's own, major, minor, dorian, phrygian,
              mixolydian, lydian, blues (bass and singer follow)
  H           harmony meow off / 3rd / 5th (needs a second SID)
  T           the open cat's settings page (and back)
  RUN/STOP    help
  <-          live play: the letter rows are pads
              Q-P drums, A-L bass, Z-/ meows; RETURN rec, DEL undo,
              CRSR up/down singer, left/right bass transpose, <- back

JOYSTICK
  Works as the mouse: it moves the pointer (faster as you hold it);
  fire (on release) is a left click, fire held half a second a right
  click.

Songs are saved under any name on the disk in drive 8 (file version
5, the settings included; one block, two when completely full). Songs
from older versions load too, with the settings as made or converted
(and old drums converted).

The panel uses UI Font V2 by Scrap / Genesis Project (2022, CSDb
release 224117), free to use. Thanks, Scrap!

MIT licence.
